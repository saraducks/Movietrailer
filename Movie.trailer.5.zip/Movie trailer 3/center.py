import movietrailer
import fresh_tomatoe

"""
Include favourite movies including title ,poster image, youtube trailer url,story line
"""
italian_job = movietrailer.Movie("Italian Job",
                                 "The Italian job is the robbery movie",
                                 "http://movies.geourdu.com/wp-content/uploads/2014/04/The-Italian-Job.jpg",
                                 "https://www.youtube.com/watch?v=hvj9vhA8ixY")

before_sun_rise = movietrailer.Movie("Before sun rise",
                                     "The story about first date ",
                                     "http://static.guim.co.uk/sys-images/Film/Pix/pictures/2010/1/20/1263986075545/Before-Sunrise-001.jpg",
                                     "https://www.youtube.com/watch?v=9v6X-Dytlko")

hungergames = movietrailer.Movie("Hunger games",
                                 "The hunger games is not simple game!",
                                 "http://ia.media-imdb.com/images/M/MV5BMjA4NDg3NzYxMF5BMl5BanBnXkFtZTcwNTgyNzkyNw@@._V1_SX640_SY720_.jpg",
                                 "https://www.youtube.com/watch?v=4S9a5V9ODuY")

troy = movietrailer.Movie("Troy", "The troy is a war between two countries",
                          "http://ia.media-imdb.com/images/M/MV5BMTk5MzU1MDMwMF5BMl5BanBnXkFtZTcwNjczODMzMw@@._V1_SX640_SY720_.jpg",
                          "https://www.youtube.com/watch?v=IKQhUzxlml8")

blackswan = movietrailer.Movie("The balck swan",
                               "The blak swan visulaises obbession to dance",
                               "http://media.salon.com/2010/08/black_swan_movie_poster-480x412.jpg",
                               "https://www.youtube.com/watch?v=5jaI1XOB-bs")
movies = [italian_job, before_sun_rise, hungergames, troy, blackswan]
"""
The following line gets all input from movies list and arrange using the html file fresh_tomatoe.py
"""
fresh_tomatoe.open_movies_page(movies)
